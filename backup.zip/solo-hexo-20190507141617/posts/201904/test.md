title: test
date: '2019-04-18 18:23:00'
updated: '2019-04-18 19:31:32'
tags: [待分类]
permalink: /articles/2019/04/18/1555582980606.html
---
<style>
  #visualisation {
    height: 500px;
  }

  .axis path,
  .axis line {
    fill: none;
    stroke: #777;
    shape-rendering: crispEdges;
  }

  .axis text {
    font-family: "Arial";
    font-size: 0.6em;
  }
  .tick {
    stroke-dasharray: 1, 2;
  }
  .bar {
    fill: FireBrick;
  }

  .legend {
    cursor: pointer;
  }

  .MathJax_SVG svg > g,
  .MathJax_SVG_Display svg > g {
    fill: black;
    stroke: black;
  }

  .legend {
    font-size: 1.2em;
  }

  .graph_inputs {
    font-size: 0.8em;
  }

  .func_text {
    font-size: 0.65em;
  }

  .deriv_func_text {
    font-size: 0.65em;
  }

  #select_activ {
    font-size: 0.8em;
  }

  .input_labels {
    font-size: 0.8em;
  }

  #func_equation {
    font: "Helvetica Neue";
    font-size: 0.9em;
  }

  #deriv_func_equation {
    font: "Helvetica Neue";
    font-size: 0.9em;
  }

  #rrelu_button {
    background-color: #009900;
    color: white;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 0.8em;
    cursor: pointer;
    margin-left: 0.3em;
  }

  #rrelu_button:hover {
    background-color: #4caf50;
    color: white;
  }
</style>
<script type="text/javascript" src="https://d3js.org/d3.v3.min.js"></script>
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS_CHTML"
></script>

<div id="browser_warning">
  <p>
    版权所有为
    <a href="https://dashee87.github.io/about/">David Sheehan</a>
    原blog地址为：<a
      href="https://dashee87.github.io/deep%20learning/visualising-activation-functions-in-neural-networks/"
      >Visualising Activation Functions in Neural Networks</a
    >
  </p>
</div>

<div id="browser_warning">
  <p>
    Note:
    注意：建议您在Chrome上查看以获得最佳体验。在Firefox和IE上，框中的等式可能无法呈现。
  </p>
</div>
<select id="select_activ" onchange="InitChart();">
  <option value="step" selected="selected">Step</option>
  <option value="identity">Identity</option>
  <option value="relu">ReLu</option>
  <option value="sigmoid">Sigmoid</option>
  <option value="tanh">Tanh</option>
  <option value="leakyrelu">Leaky ReLU</option>
  <option value="prelu">PReLU</option>
  <option value="rrelu">RReLU</option>
  <option value="elu">ELU</option>
  <option value="selu">SELU</option>
  <option value="srelu">SReLU</option>
  <!--<option value="probit">Probit</option>-->
  <option value="hardsigmoid">Hard Sigmoid</option>
  <option value="hardtanh">Hard Tanh</option>
  <option value="lctanh">LeCun Tanh</option>
  <option value="arctan">ArcTan</option>
  <option value="softsign">SoftSign</option>
  <option value="softplus">Softplus</option>
  <option value="sign">Signum</option>
  <option value="bentid">Bent Identity</option>
  <option value="symmsigmoid">Symmetrical Sigmoid</option>
  <option value="loglog">Log Log</option>
  <option value="gaussian">Gaussian</option>
  <option value="absolute">Absolute</option>
  <option value="sinusoid">Sinusoid</option>
  <option value="cos">Cos</option>
  <option value="sinc">Sinc</option>
</select>
<form name="message" method="post" id="plot_inputs">
  <div style="float:left;margin-right:20px;margin-left:100px;">
    <label
      for="alpha_input"
      style="display: none"
      class="input_labels"
      id="alpha_input_label"
      >α<sub> </sub
    ></label>
    <input
      id="alpha_input"
      class="graph_inputs"
      size="5"
      type="text"
      value="0.7"
      style="display: none;"
      onchange="InitChart();"
    />
  </div>

  <div style="float:left;margin-right:20px;">
    <label
      for="alpha_input_r"
      style="display: none"
      class="input_labels"
      id="alpha_input_r_label"
      >α<sub>r</sub></label
    >
    <input
      id="alpha_input_r"
      class="graph_inputs"
      size="5"
      type="text"
      value="0.4"
      style="display: none;"
      onchange="InitChart();"
    />
  </div>

  <div style="float:left;margin-right:20px;">
    <label
      for="t_input_l"
      style="display: none"
      class="input_labels"
      id="t_input_l_label"
      >t<sub>l</sub></label
    >
    <input
      id="t_input_l"
      class="graph_inputs"
      size="5"
      type="text"
      value="-1.0"
      style="display: none;"
      onchange="InitChart();"
    />
  </div>

  <div style="float:left;margin-right:20px;">
    <label
      for="t_input_r"
      style="display: none"
      class="input_labels"
      id="t_input_r_label"
      >t<sub>r</sub></label
    >
    <input
      id="t_input_r"
      class="graph_inputs"
      size="5"
      type="text"
      value="1.0"
      style="display: none;"
      onchange="InitChart();"
    />
  </div>

  <br style="clear:both;" />
</form>
<button
  type="button"
  onclick="InitChart();"
  id="rrelu_button"
  style="display: none;margin-left:20px;"
>
  Random α
</button>
<div id="legendContainer" class="legendContainer" style="width:100%">
  <svg id="visualisation" width="100%" height="500px" height="80vh"></svg>
  <div
    id="func_primer"
    style="margin-left:20px;font-size:0.8em;margin-right:20px"
  >
    <p>
      这种激活函数更具理论性而非实际性，模仿生物神经元的全有或全无特性。它对神经网络没有
      用，因为它的导数是零（除了0，它是未定义的）。这意味着基于梯度的优化方法是不可行的。
    </p>
  </div>
</div>
<br />

<script type="text/javascript">
  MathJax.Hub.Config({
    tex2jax: {
      inlineMath: [["$", "$"], ["\\(", "\\)"]],
      processEscapes: true
    }
  });

  function erf(x) {
    var z;
    const ERF_A = 0.147;
    var the_sign_of_x;
    if (0 == x) {
      the_sign_of_x = 0;
      return 0;
    } else if (x > 0) {
      the_sign_of_x = 1;
    } else {
      the_sign_of_x = -1;
    }

    var one_plus_axsqrd = 1 + ERF_A * x * x;
    var four_ovr_pi_etc = 4 / Math.PI + ERF_A * x * x;
    var ratio = four_ovr_pi_etc / one_plus_axsqrd;
    ratio *= x * -x;
    var expofun = Math.exp(ratio);
    var radical = Math.sqrt(1 - expofun);
    z = radical * the_sign_of_x;
    return z;
  }

  // https://stackoverflow.com/questions/12556685/is-there-a-javascript-implementation-of-the-inverse-error-function-akin-to-matl

  function erfINV(inputX) {
    var _a = (8 * (Math.PI - 3)) / (3 * Math.PI * (4 - Math.PI));
    var _x = parseFloat(inputX);
    var signX = _x < 0 ? -1.0 : 1.0;

    var oneMinusXsquared = 1.0 - _x * _x;
    var LNof1minusXsqrd = Math.log(oneMinusXsquared);
    var PI_times_a = Math.PI * _a;

    var firstTerm = Math.pow(2.0 / PI_times_a + LNof1minusXsqrd / 2.0, 2);
    var secondTerm = LNof1minusXsqrd / _a;
    var thirdTerm = 2 / PI_times_a + LNof1minusXsqrd / 2.0;

    var primaryComp = Math.sqrt(Math.sqrt(firstTerm - secondTerm) - thirdTerm);

    var scaled_R = signX * primaryComp;
    return scaled_R;
  }

  var delay = 200;
  var activ_func = document.getElementById("select_activ").value;

  var lineData = [];
  var lineData_deriv = [];

  func_tags = [
    {
      func_tex:
        "$f(x) =\\begin{cases}1 & \\text{for } x\\geq0\\\\0 & \\text{for } x<0\\end{cases} $",
      func_range: "{0, 1}",
      func_contin: "C" + "⁻¹",
      func_mono: "✅",
      func_origin: "❌",
      func_symm: "不对称",
      func_ref: "",
      func_primer:
        "这种激活函数更具理论性而非实际性, 包括<b>Step</b> (也包括, <b>Binary Step</b> 或 <b>Heaviside</b>) 模仿生物神经元的全有或全无特性。它对神经网络没有用，因为它的导数是零（除了0，它是未定义的）。这意味着基于梯度的优化方法是不可行的"
    }
  ];

  deriv_func_tags = [
    {
      deriv_func_tex:
        "$f'(x) =\\begin{cases}0 & \\text{for } x\\neq0\\\\? & \\text{for } x=0\\end{cases} $",
      deriv_func_range: "{0}",
      deriv_func_contin: "❌",
      deriv_func_mono: "❌",
      deriv_func_symm: "❌",
      deriv_func_van: "No",
      deriv_func_exp: "No",
      deriv_func_sat: "No",
      deriv_func_dead: "Yes"
    }
  ];

  axis_limits = [-3, 3, -1.3, 1.3];

  for (var i = -3; i <= 3; i = i + 0.001) {
    lineData.push({
      x: I,
      y: i >= 0
    });
    lineData_deriv.push({
      x: I,
      y: 0
    });
  }

  var vis = d3.select("#visualisation"),
    WIDTH = parseInt(document.getElementById("browser_warning").offsetWidth),
    HEIGHT = parseInt(vis.style("height")),
    //   HEIGHT = parseInt(document.documentElement.clientHeight)*0.8,
    MARGINS = {
      top: HEIGHT / 25.0,
      right: WIDTH / 2.5,
      bottom: HEIGHT / 25.0,
      left: WIDTH / 50.0
    },
    boxmargin = (HEIGHT - MARGINS.top) / 24.0,
    boxmargin_horizontal = MARGINS.right / 2.2,
    rect_margin = MARGINS.right / 50.0,
    xRange = d3.scale
      .linear()
      .range([MARGINS.left, WIDTH - MARGINS.right])
      .domain(axis_limits.slice(0, 2)),
    yRange = d3.scale
      .linear()
      .range([HEIGHT - MARGINS.top, MARGINS.bottom])
      .domain(axis_limits.slice(2, 4)),
    xAxis = d3.svg
      .axis()
      .scale(xRange)
      .tickSize(5)
      .tickSubdivide(true),
    yAxis = d3.svg
      .axis()
      .scale(yRange)
      .tickSize(5)
      .orient("left")
      .tickSubdivide(true);

  vis
    .append("svg:g")
    .attr("class", "x axis")
    .attr(
      "transform",
      "translate(0," + (HEIGHT - MARGINS.bottom + MARGINS.top) / 2 + ")"
    )
    .attr("id", "graph_xaxis")
    .call(xAxis);

  vis
    .append("svg:g")
    .attr("class", "y axis")
    .attr(
      "transform",
      "translate(" + (WIDTH - MARGINS.right + MARGINS.left) / 2 + ",0)"
    )
    .attr("id", "graph_yaxis")
    .call(yAxis);

  vis
    .selectAll(".tick")
    .filter(function(d) {
      return d === 0;
    })
    .remove();

  var lineFunc = d3.svg
    .line()
    .x(function(d) {
      return xRange(d.x);
    })
    .y(function(d) {
      return yRange(d.y);
    })
    .interpolate("linear");

  vis
    .selectAll(".tick")
    .filter(function(d) {
      return d === 0;
    })
    .remove();

  var asymptotes = d3.svg
    .line()
    .x([-3, 3])
    .y([5, 5])
    .interpolate("linear");

  var asymptote_top = 5,
    asymptote_bottom = -5;

  //d3.select("#func").remove();

  vis
    .append("svg:path")
    .attr("d", lineFunc(lineData))
    .attr("stroke", "blue")
    .attr("stroke-width", 3)
    .attr("id", "func")
    .attr("fill", "none");

  vis
    .append("svg:path")
    .attr("d", lineFunc(lineData_deriv))
    .attr("stroke", "orange")
    .attr("stroke-width", 2)
    .attr("id", "deriv_func")
    .attr("fill", "none");

  vis
    .append("svg:path")
    .attr(
      "d",
      lineFunc([{ x: axis_limits[0], y: 5 }, { x: axis_limits[1], y: 5 }])
    )
    .attr("stroke", "gray")
    .attr("stroke-width", 2)
    .style("stroke-dasharray", "3, 3")
    .attr("id", "top_asymptote")
    .attr("fill", "none");

  vis
    .append("svg:path")
    .attr(
      "d",
      lineFunc([{ x: axis_limits[0], y: -5 }, { x: axis_limits[1], y: -5 }])
    )
    .attr("stroke", "gray")
    .attr("stroke-width", 2)
    .style("stroke-dasharray", "3, 3")
    .attr("id", "bottom_asymptote")
    .attr("fill", "none");

  vis
    .append("rect")
    .attr("x", WIDTH - MARGINS.right + rect_margin)
    .attr("y", MARGINS.top)
    .attr("width", MARGINS.right - rect_margin * 2.0)
    .attr("height", (HEIGHT - MARGINS.top) / 2 - boxmargin)
    .attr("rx", 10)
    .attr("ry", 10)
    .attr("stroke", "blue")
    .attr("stroke-width", "5")
    .attr("stroke-opacity", "0.4")
    .attr("fill-opacity", "0.1")
    .style("fill", "blue")
    .attr("class", "info_rect")
    .attr("id", "func_rect");

  vis
    .append("foreignObject")
    .data(func_tags)
    .attr("id", "func_equation")
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2)
    .attr("y", MARGINS.top + boxmargin / 2)
    .append("xhtml:div")
    .attr("class", "func_text")
    .text(function(d) {
      return d.func_tex;
    });

  vis
    .append("text")
    .data(func_tags)
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2)
    .attr("y", MARGINS.top + boxmargin * 5)
    .attr("id", "func_range")
    .attr("class", "func_text")
    .text(function(d) {
      return "值域: " + d.func_range;
    });

  vis
    .append("text")
    .data(func_tags)
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2)
    .attr("y", MARGINS.top + boxmargin * 6.3)
    .attr("id", "func_mono")
    .attr("class", "func_text")
    .text(function(d) {
      return "单调性: " + d.func_mono;
    });

  vis
    .append("text")
    .data(func_tags)
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2)
    .attr("y", MARGINS.top + boxmargin * 7.6)
    .attr("id", "func_contin")
    .attr("class", "func_text")
    .text(function(d) {
      return "连续性: " + d.func_contin;
    });

  vis
    .append("text")
    .data(func_tags)
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2)
    .attr("y", MARGINS.top + boxmargin * 8.9)
    .attr("id", "func_origin")
    .attr("class", "func_text")
    .text(function(d) {
      return "Identity at Origin: " + d.func_origin;
    });

  vis
    .append("text")
    .data(func_tags)
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2)
    .attr("y", MARGINS.top + boxmargin * 10.2)
    .attr("id", "func_symm")
    .attr("class", "func_text")
    .text(function(d) {
      return "对称性: " + d.func_symm;
    });

  vis
    .append("text")
    .attr("x", WIDTH - boxmargin_horizontal / 1.7)
    .attr("y", MARGINS.top + boxmargin * 10.2)
    .attr("xlink:href", "https://dashee87.github.io/")
    .attr("id", "func_ref")
    .attr("class", "func_text")
    .attr("fill", "red")
    .html("");

  // derivative rectangle

  vis
    .append("rect")
    .attr("x", WIDTH - MARGINS.right + rect_margin)
    .attr("y", MARGINS.top + HEIGHT / 2)
    .attr("width", MARGINS.right - rect_margin * 2.0)
    .attr("height", (HEIGHT - MARGINS.top) / 2 - boxmargin)
    .attr("rx", 10)
    .attr("ry", 10)
    .attr("stroke", "orange")
    .attr("stroke-width", "5")
    .attr("stroke-opacity", "0.4")
    .attr("fill-opacity", "0.1")
    .style("fill", "orange")
    .attr("class", "info_rect)")
    .attr("id", "deriv_func_rect");

  vis
    .append("foreignObject")
    .data(deriv_func_tags)
    .attr("id", "deriv_func_equation")
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
    .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin / 2)
    .append("xhtml:div")
    .attr("class", "deriv_func_text")
    .html(function(d) {
      return d.deriv_func_tex;
    });

  if (navigator.userAgent.toLowerCase().indexOf("firefox") > -1) {
    vis
      .select("#func_equation")
      .attr("width", MARGINS.right - rect_margin * 2)
      .attr("height", boxmargin * 3);

    vis
      .select("#deriv_func_equation")
      .attr("width", MARGINS.right - rect_margin * 2)
      .attr("height", boxmargin * 3);
  }

  vis
    .append("text")
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
    .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 5)
    .data(deriv_func_tags)
    .attr("id", "deriv_func_range")
    .attr("class", "deriv_func_text")
    .text(function(d) {
      return "值域: " + d.deriv_func_range;
    });

  vis
    .append("text")
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
    .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 6.3)
    .data(deriv_func_tags)
    .attr("id", "deriv_func_mono")
    .attr("class", "deriv_func_text")
    .style("colour", "blue")
    .text(function(d) {
      return "单调性: " + d.deriv_func_mono;
    });

  vis
    .append("text")
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
    .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 7.6)
    .data(deriv_func_tags)
    .attr("id", "deriv_func_contin")
    .attr("class", "deriv_func_text")
    .text(function(d) {
      return "连续性: " + d.deriv_func_contin;
    });

  vis
    .append("text")
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
    .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 8.9)
    .attr("id", "deriv_func_van")
    .attr("class", "deriv_func_text")
    .append("svg:tspan")
    .text("梯度消失: ")
    .append("svg:tspan")
    .style("fill", "#00e600")
    .text(deriv_func_tags[0].deriv_func_van);

  vis
    .append("text")
    .attr("x", WIDTH - boxmargin_horizontal)
    .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 8.9)
    .attr("id", "deriv_func_exp")
    .attr("class", "deriv_func_text")
    .append("svg:tspan")
    .text("梯度爆炸: ")
    .append("svg:tspan")
    .style("fill", "#00e600")
    .text(deriv_func_tags[0].deriv_func_exp);

  vis
    .append("text")
    .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
    .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 10.3)
    .attr("id", "deriv_func_sat")
    .attr("class", "deriv_func_text")
    .append("svg:tspan")
    .text("神经元饱和: ")
    .append("svg:tspan")
    .style("fill", "#00e600")
    .text(deriv_func_tags[0].deriv_func_sat);

  vis
    .append("text")
    .attr("x", WIDTH - boxmargin_horizontal)
    .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 10.3)
    .attr("id", "deriv_func_dead")
    .attr("class", "deriv_func_text")
    .append("svg:tspan")
    .text("神经元死亡: ")
    .append("svg:tspan")
    .style("fill", "red")
    .text(deriv_func_tags[0].deriv_func_dead);

  vis
    .append("text")
    .attr("x", MARGINS.left)
    .attr("y", MARGINS.top + 30)
    .attr("class", "legend")
    .attr("id", "func_text")
    .style("fill", "steelblue")
    .on("click", function() {
      // Determine if current line is visible
      var active = func.active ? false : true,
        newOpacity = active ? 0 : 1;
      // Hide or show the elements
      d3.select("#func").style("opacity", newOpacity);
      d3.select("#func_text").style("opacity", active ? 0.5 : 1);
      d3.select("#func_rect")
        .transition()
        .duration(1000)
        .attr("height", active ? 0 : (HEIGHT - MARGINS.top) / 2 - boxmargin);
      if (active) {
        d3.selectAll(".func_text")
          .transition()
          .delay(function(d, i) {
            return 400 - delay * I;
          })
          .style("opacity", active ? 0 : 1);
      } else {
        d3.selectAll(".func_text")
          .transition()
          .delay(function(d, i) {
            return 300 + (delay * i) / 2;
          })
          .style("opacity", active ? 0 : 1);
      }
      // Update whether or not the elements are active
      func.active = active;
    })
    .text("f (x)");

  // Add the red line title
  vis
    .append("text")
    .attr("x", MARGINS.left)
    .attr("y", MARGINS.top + 30 + 30)
    .attr("class", "legend")
    .attr("id", "deriv_text")
    .style("fill", "orange")
    .on("click", function() {
      // Determine if current line is visible
      var active = deriv_func.active ? false : true,
        newOpacity = active ? 0 : 1;
      // Hide or show the elements
      d3.select("#deriv_func").style("opacity", newOpacity);
      d3.select("#deriv_text").style("opacity", active ? 0.5 : 1);
      d3.select("#deriv_func_rect")
        .transition()
        .duration(1000)
        .attr("height", active ? 0 : (HEIGHT - MARGINS.top) / 2 - boxmargin);
      if (active) {
        d3.selectAll(".deriv_func_text")
          .transition()
          .delay(function(d, i) {
            return 400 - delay * I;
          })
          .style("opacity", active ? 0 : 1);
      } else {
        d3.selectAll(".deriv_func_text")
          .transition()
          .delay(function(d, i) {
            return 250 + (delay * i) / 2.5;
          })
          .style("opacity", active ? 0 : 1);
      }
      // Update whether or not the elements are active
      deriv_func.active = active;
    })
    .text("f '(x)");

  d3.select(window).on("resize", function() {
    vis = d3.select("#visualisation");
    WIDTH = parseInt(document.getElementById("browser_warning").offsetWidth);
    HEIGHT = parseInt(vis.style("height"));
    MARGINS = {
      top: HEIGHT / 25.0,
      right: WIDTH / 2.5,
      bottom: HEIGHT / 25.0,
      left: WIDTH / 50.0
    };
    boxmargin = (HEIGHT - MARGINS.top) / 24.0;
    rect_margin = MARGINS.right / 50.0;
    (boxmargin_horizontal = MARGINS.right / 2.2),
      (xRange = d3.scale
        .linear()
        .range([MARGINS.left, WIDTH - MARGINS.right])
        .domain(axis_limits.slice(0, 2)));

    yRange = d3.scale
      .linear()
      .range([HEIGHT - MARGINS.top, MARGINS.bottom])
      .domain(axis_limits.slice(2, 4));

    xAxis = d3.svg
      .axis()
      .scale(xRange)
      .tickSize(5)
      .tickSubdivide(true);

    yAxis = d3.svg
      .axis()
      .scale(yRange)
      .tickSize(5)
      .orient("left")
      .tickSubdivide(true);

    vis
      .select("#graph_xaxis")
      .attr(
        "transform",
        "translate(0," + (HEIGHT - MARGINS.bottom + MARGINS.top) / 2 + ")"
      )
      .call(xAxis);

    vis
      .select("#graph_yaxis")
      .attr(
        "transform",
        "translate(" + (WIDTH - MARGINS.right + MARGINS.left) / 2 + ",0)"
      )
      .call(yAxis);

    vis
      .selectAll(".tick")
      .filter(function(d) {
        return d === 0;
      })
      .remove();

    lineFunc = d3.svg
      .line()
      .x(function(d) {
        return xRange(d.x);
      })
      .y(function(d) {
        return yRange(d.y);
      })
      .interpolate("linear");

    vis
      .select("#top_asymptote")
      .attr(
        "d",
        lineFunc([
          { x: axis_limits[0], y: asymptote_top },
          { x: axis_limits[1], y: asymptote_top }
        ])
      );

    vis
      .select("#bottom_asymptote")
      .attr(
        "d",
        lineFunc([
          { x: axis_limits[0], y: asymptote_bottom },
          { x: axis_limits[1], y: asymptote_bottom }
        ])
      );

    //d3.select("#func").remove();

    vis.select("#func").attr("d", lineFunc(lineData));

    vis.select("#deriv_func").attr("d", lineFunc(lineData_deriv));

    vis
      .select("#func_rect")
      .attr("x", WIDTH - MARGINS.right + rect_margin)
      .attr("y", MARGINS.top)
      .attr("width", MARGINS.right - rect_margin * 2.0)
      .attr("height", (HEIGHT - MARGINS.top) / 2 - boxmargin);

    vis
      .select("#func_equation")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + boxmargin / 2);

    vis
      .select("#func_range")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + boxmargin * 5);

    vis
      .select("#func_mono")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + boxmargin * 6.3);

    vis
      .select("#func_contin")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + boxmargin * 7.6);

    vis
      .select("#func_origin")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + boxmargin * 8.9);

    vis
      .select("#func_symm")
      .data(func_tags)
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + boxmargin * 10.2);

    vis
      .select("#func_ref")
      .attr("x", WIDTH - boxmargin_horizontal / 1.7)
      .attr("y", MARGINS.top + boxmargin * 10.2);

    // derivative rectangle

    vis
      .select("#deriv_func_rect")
      .attr("x", WIDTH - MARGINS.right + rect_margin)
      .attr("y", MARGINS.top + HEIGHT / 2)
      .attr("width", MARGINS.right - rect_margin * 2.0)
      .attr("height", (HEIGHT - MARGINS.top) / 2 - boxmargin);

    vis
      .select("#deriv_func_equation")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin / 2);

    vis
      .select("#deriv_func_range")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 5);

    vis
      .select("#deriv_func_mono")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 6.3);

    vis
      .select("#deriv_func_contin")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 7.6);

    vis
      .select("#deriv_func_van")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 8.9);

    vis
      .select("#deriv_func_exp")
      .attr("x", WIDTH - boxmargin_horizontal)
      .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 8.9);

    vis
      .select("#deriv_func_sat")
      .attr("x", WIDTH - MARGINS.right + rect_margin * 2.0)
      .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 10.3);

    vis
      .select("#deriv_func_dead")
      .attr("x", WIDTH - boxmargin_horizontal)
      .attr("y", MARGINS.top + HEIGHT / 2 + boxmargin * 10.3);
  });

  function InitChart() {
    var myClasses = document.getElementById("plot_inputs"),
      mylabels = document.getElementsByTagName("label");
    for (i = 0; i < myClasses.length; i++) {
      myClasses[i].style.display = "none";
      mylabels[i].style.display = "none";
    }
    document.getElementById("rrelu_button").style.display = "none";
    var activ_func = document.getElementById("select_activ").value;

    lineData = [];
    lineData_deriv = [];

    asymptote_top = 5;
    asymptote_bottom = -5;

    switch (activ_func) {
      case "relu":
        func_tags = [
          {
            func_tex:
              "$f(x) =\\begin{cases}x & \\text{for } x\\geq0\\\\0 & \\text{for } x<0\\end{cases} $",
            func_range: "[0, ∞)",
            func_contin: "C" + "⁰",
            func_mono: "✅",
            func_origin: "❌",
            func_symm: "不对称",
            func_ref: "http://dl.acm.org/citation.cfm?id=3104322.3104425",
            func_primer:
              "<b>整流线性单元</b> (<b>ReLU</b>)被认为是神经网络中最常见的激活函数。它保留了阶梯函数的生物学动机（神经元仅在输入超过阈值时触发），但在正数输入处具有非零导数，这允许基于梯度的学习（尽管导数在0时未定义）。它的计算速度也很快，因为函数及其导数都不涉及复杂的数学运算。然而，由于在非正输入时导数为0，ReLU可能会受到缓慢学习甚至死神经元的影响，其中具有负值输入的神经元由于零值梯度而无法更新其权重，使得它们对于剩下的训练阶段沉默。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'(x) =\\begin{cases}1 & \\text{for } x\\geq0\\\\0 & \\text{for } x<0\\end{cases} $",
            deriv_func_range: "{0,1}",
            deriv_func_contin: "❌",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "No",
            deriv_func_exp: "No",
            deriv_func_sat: "No",
            deriv_func_dead: "Yes"
          }
        ];

        axis_limits = [-3, 3, -3, 3];
        for (var i = -3; i < 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: (i > 0) * I
          });
          lineData_deriv.push({
            x: I,
            y: i >= 0
          });
        }
        break;
      case "step":
        func_tags = [
          {
            func_tex:
              "$f(x) =\\begin{cases}1 & \\text{for } x\\geq0\\\\0 & \\text{for } x<0\\end{cases} $",
            func_range: "{0, 1}",
            func_contin: "C" + "⁻¹",
            func_mono: "✅",
            func_origin: "✅",
            func_symm: "不对称",
            func_ref: "",
            func_primer:
              "这种激活函数更具理论性而非实际性, 包括<b>Step</b> (也包括, <b>Binary Step</b> 或 <b>Heaviside</b>) 模仿生物神经元的全有或全无特性。它对神经网络没有用，因为它的导数是零（除了0，它是未定义的）。这意味着基于梯度的优化方法是不可行的"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'(x) =\\begin{cases}0 & \\text{for } x\\neq0\\\\? & \\text{for } x=0\\end{cases} $",
            deriv_func_range: "{0}",
            deriv_func_contin: "❌",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "No",
            deriv_func_exp: "No",
            deriv_func_sat: "No",
            deriv_func_dead: "Yes"
          }
        ];

        axis_limits = [-3, 3, -1.3, 1.3];
        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: i >= 0
          });
          lineData_deriv.push({
            x: I,
            y: 0
          });
        }
        break;

      case "sign":
        func_tags = [
          {
            func_tex:
              "$f(x) =\\begin{cases}1 & x>0\\\\-1 &  x<0 \\\\0 &  x=0\\end{cases} $",
            func_range: "{-1,0, 1}",
            func_contin: "C" + "⁻¹",
            func_mono: "✅",
            func_origin: "❌",
            func_symm: "Anti-Symmetrical",
            func_ref: "",
            func_primer:
              "The <b>Signum</b> (or just <b>Sign</b>) is a scaled version of the binary step activation function. It takes the value -1 and 1 for negative and postive values, respectively, and zero at the origin. Though lacking the biological motivation of the step function, the function is anti-symmetrical, which is thought to be a favourable trait for an activation function."
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'(x) =\\begin{cases}0 & \\text{for } x\\neq0\\\\? & \\text{for } x=0\\end{cases} $",
            deriv_func_range: "{0}",
            deriv_func_contin: "❌",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "No",
            deriv_func_exp: "No",
            deriv_func_sat: "No",
            deriv_func_dead: "Yes"
          }
        ];

        axis_limits = [-3, 3, -1.5, 1.5];
        for (var i = -3; i <= 3; i = i + 0.001) {
          if (i == 0) {
            lineData.push({
              x: I,
              y: 0
            });
          } else {
            lineData.push({
              x: I,
              y: 2 * (i > 0) - 1
            });
            lineData_deriv.push({
              x: I,
              y: 0
            });
          }
        }
        break;

      case "identity":
        func_tags = [
          {
            func_tex: "$\\begin{align*}f(x) = x\\end{align*}$",
            func_range: "(-∞, ∞)",
            func_contin: "C" + "∞",
            func_mono: "✅",
            func_origin: "✅",
            func_symm: "Anti-Symmetrical",
            func_ref: "",
            func_primer:
              "使用 <b>Identity</b> 使用Identity激活功能，节点输出等于其输入。它非常适合基础行为是线性的任务，类似于线性回归。当存在非线性时，单独的激活函数是不够的，尽管它仍然可以用作最终输出节点上的激活函数以用于类似回归的任务。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex: "$\\begin{align*}f'(x) = 1\\end{align*}$",
            deriv_func_range: "{1}",
            deriv_func_contin: "✅",
            deriv_func_mono: "✅",
            deriv_func_symm: "✅",
            deriv_func_van: "No",
            deriv_func_exp: "No",
            deriv_func_sat: "No",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -3, 3];
        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: I
          });
          lineData_deriv.push({
            x: I,
            y: 1
          });
        }
        break;
      case "sigmoid":
        func_tags = [
          {
            func_tex:
              "$\\begin{align*}f(x) = \\frac{1}{1 + e^{-x}} \\end{align*}$",
            func_range: "(0, 1)",
            func_contin: "C" + "∞",
            func_mono: "✅",
            func_origin: "❌",
            func_symm: "不对称",
            func_ref: "",
            func_primer:
              "<b>Logistic Sigmoid</b>（或更常见的只是Sigmoid）激活函数从逻辑回归中的角色（0到1）中众所周知，它将概率概念引入神经网络。它的导数非零且易于计算（它是其原始输出的函数）。然而，由于Tanh是反对称的并且以原点为中心。它逐渐被Tanh取代。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f'(x) &= \\frac{e^{-x}}{(1+e^{-x})^2} \\\\&= f(x)(1-f(x)) \\end{align*}$",
            deriv_func_range: "(0,0.25)",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "✅",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -1.5, 1.5];
        for (var i = -3; i <= 3; i = i + 0.001) {
          asymptote_top = 1;
          temp_sigmoid = 1.0 / (1.0 + Math.exp(-i));
          lineData.push({
            x: I,
            y: temp_sigmoid
          });
          lineData_deriv.push({
            x: I,
            y: temp_sigmoid * (1 - temp_sigmoid)
          });
        }
        break;
      case "arctan":
        func_tags = [
          {
            func_tex: "$\\begin{align*}f(x) =\\tan^{-1}(x) \\end{align*}$",
            func_range: "(-π/2, π/2)",
            func_contin: "C" + "∞",
            func_mono: "❌",
            func_origin: "✅",
            func_symm: "Symmetrical",
            func_ref: "",
            func_primer:
              "视觉上和Tanh类似，更为平坦。默认值域， (-π/2, π/2)。导数很慢趋近于0，但导数计算量大于Tanh。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f'(x)=\\frac{1}{x^2+1} \\end{align*}$",
            deriv_func_range: "(0,1]",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "✅",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -1.6, 1.6];
        for (var i = -3; i <= 3; i = i + 0.001) {
          asymptote_top = Math.PI / 2;
          asymptote_bottom = -Math.PI / 2;
          lineData.push({
            x: I,
            y: Math.atan(i)
          });
          lineData_deriv.push({
            x: I,
            y: 1 / (Math.pow(i, 2) + 1)
          });
        }
        break;
      case "softsign":
        func_tags = [
          {
            func_tex: "$\\begin{align*}f(x)=\\frac{x}{1+|x|} \\end{align*}$",
            func_range: "(0, ∞)",
            func_contin: "C¹",
            func_mono: "✅",
            func_origin: "✅",
            func_symm: "Anti-Symmetrical",
            func_ref:
              "http://www.iro.umontreal.ca/~lisa/publications2/index.php/attachments/single/205",
            func_primer:
              "<b>Softsign</b> 和Tanh类似，默认值域， (-1, 1)。导数很慢趋近于0，但导数计算量大于Tanh。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f'(x)=\\frac{1}{(1+|x|)^2} \\end{align*}$",
            deriv_func_range: "(0,1]",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "✅",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-6, 6, -1.6, 1.6];
        for (var i = -6; i <= 6; i = i + 0.002) {
          asymptote_top = 1;
          asymptote_bottom = -1;
          lineData.push({
            x: I,
            y: i / (1 + Math.abs(i))
          });
          lineData_deriv.push({
            x: I,
            y: 1 / Math.pow(1 + Math.abs(i), 2)
          });
        }
        break;
      case "softplus":
        func_tags = [
          {
            func_tex: "$\\begin{align*}f(x)=\\ln(1+e^x) \\end{align*}$",
            func_range: "(0, ∞)",
            func_contin: "C" + "∞",
            func_mono: "✅",
            func_origin: "❌",
            func_symm: "不对称",
            func_ref:
              "http://proceedings.mlr.press/v15/glorot11a/glorot11a.pdf",
            func_primer:
              "ReLu的平滑替代品，定义域上连续可导；但是不关于0对称，由于导数总<1，可能会梯度消失。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f'(x)=\\frac{1}{1+e^{-x}}\\end{align*}$",
            deriv_func_range: "(0,1)",
            deriv_func_contin: "✅",
            deriv_func_mono: "✅",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -3, 3];
        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: Math.log(1 + Math.exp(i), 2)
          });
          lineData_deriv.push({
            x: I,
            y: 1 / (1 + Math.exp(-i))
          });
        }
        break;

      case "bentid":
        func_tags = [
          {
            func_tex:
              "$\\begin{align*}f(x)=\\frac{\\sqrt{x^2 + 1} - 1}{2} + x \\end{align*}$",
            func_range: "(-∞, ∞)",
            func_contin: "C" + "∞",
            func_mono: "✅",
            func_origin: "✅",
            func_symm: "不对称",
            func_ref: "",
            func_primer:
              "A sort of compromise between Identity and ReLU activation, <b>Bent Identity</b> allows non-linear behaviours, while its non-zero derivative promotes efficient learning and overcomes the issues of dead neurons associated with ReLU. As its derivative can return values either side of 1, it can be susceptible to both exploding and vanishing gradients."
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f'(x)=\\frac{x}{2\\sqrt{x^2 + 1}} + 1\\end{align*}$",
            deriv_func_range: "(0.5, 1.5)",
            deriv_func_contin: "✅",
            deriv_func_mono: "✅",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes",
            deriv_func_exp: "Yes",
            deriv_func_sat: "No",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -3, 3];
        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: (Math.sqrt(Math.pow(i, 2) + 1) - 1) / 2.0 + I
          });
          lineData_deriv.push({
            x: I,
            y: i / (2 * Math.sqrt(Math.pow(i, 2) + 1)) + 1
          });
        }
        break;

      case "sinusoid":
        func_tags = [
          {
            func_tex: "$\\begin{align*}f(x)=\\sin(x) \\end{align*}$",
            func_range: "[-1, -1]",
            func_contin: "C" + "∞",
            func_mono: "❌",
            func_origin: "✅",
            func_symm: "Anti-Symmetrical",
            func_ref: "",
            func_primer:
              "<b>Sinusoid</b> (or simply <b>Sin</b>)， 值域[-1,1], 原点为中心，反对称，连续可导."
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex: "$\\begin{align*}f'(x)=\\cos(x)\\end{align*}$",
            deriv_func_range: "[-1, -1]",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "No",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -1.5, 1.5];

        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: Math.sin(i)
          });
          lineData_deriv.push({
            x: I,
            y: Math.cos(i)
          });
        }
        break;

      case "cos":
        func_tags = [
          {
            func_tex: "$\\begin{align*}f(x)=\\cos(x) \\end{align*}$",
            func_range: "[-1, -1]",
            func_contin: "C" + "∞",
            func_mono: "❌",
            func_origin: "❌",
            func_symm: "Symmetrical",
            func_ref: "",
            func_primer:
              "<b>Cos</b> (or <b>Cosine</b>) 值域[-1,1], 轴对称，连续可导."
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex: "$\\begin{align*}f'(x)=\\-sin(x)\\end{align*}$",
            deriv_func_range: "[-1, -1]",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "✅",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "No",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -1.5, 1.5];

        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: Math.cos(i)
          });
          lineData_deriv.push({
            x: I,
            y: -Math.sin(i)
          });
        }
        break;

      case "sinc":
        func_tags = [
          {
            func_tex:
              "$f(x)=\\begin{cases}1 & \\text{for } x = 0\\\\\\frac{\\sin(x)}{x} & \\text{for } x \\ne 0\\end{cases}$",
            func_range: "[≈-0.2172,1]",
            func_contin: "C" + "∞",
            func_mono: "❌",
            func_origin: "❌",
            func_symm: "Symmetrical",
            func_ref:
              "https://www.spiedigitallibrary.org/conference-proceedings-of-spie/2760/1/Function-approximation-using-a-sinc-neural-network/10.1117/12.235959.short?SSO=1",
            func_primer:
              "<b>Sinc</b> (全名<b>Cardinal Sine</b> )代表了傅立叶变换的矩形函数。作为一种激活函数，它可以完全可导和对称，但它很容易梯度消失。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'(x)=\\begin{cases}0 & \\text{for } x = 0\\\\\\frac{\\cos(x)}{x} - \\frac{\\sin(x)}{x^2} & \\text{for } x \\ne 0\\end{cases}$",
            deriv_func_range: "(≈-0.4362, ≈0.4362)",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-6, 6, -1.5, 1.5];
        for (var i = -6; i <= 6; i = i + 0.002) {
          if (i == 0) {
            lineData.push({
              x: I,
              y: Math.sin(i) / I
            });
            lineData_deriv.push({
              x: I,
              y: Math.sin(i) / I
            });
          } else {
            lineData.push({
              x: I,
              y: Math.sin(i) / I
            });
            lineData_deriv.push({
              x: I,
              y: Math.cos(i) / i - Math.sin(i) / Math.pow(i, 2)
            });
          }
        }
        break;

      case "tanh":
        func_tags = [
          {
            func_tex:
              "$\\begin{align*}f(x)&=\\tanh(x)\\\\&=\\frac{2}{1+e^{-2x}}-1\\end{align*}$",
            func_range: "(-1, -1)",
            func_contin: "C" + "∞",
            func_mono: "✅",
            func_origin: "✅",
            func_symm: "Anti-Symmetrical",
            func_ref: "",
            func_primer:
              "逐渐取代logistic sigmoid函数作为分类任务的激活函数，Tanh（Hyperbolic Tan）具有神经网络中有利的各种特征。它完全可微，以零和反对称为中心。可以采用更平坦的变形（log-log，softsign，对称sigmoid等），减轻缓慢学习和/或消失梯度的现象。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f'(x)&=1-\\tanh^2(x)\\\\&=1-f(x)^2\\end{align*}$",
            deriv_func_range: "(0, 1]",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "✅",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -1.5, 1.5];
        asymptote_top = 1;
        asymptote_bottom = -1;
        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: Math.tanh(i)
          });
          lineData_deriv.push({
            x: I,
            y: 1 - Math.pow(Math.tanh(i), 2)
          });
        }
        break;

      case "lctanh":
        func_tags = [
          {
            func_tex:
              "$\\begin{align*}f(x)&=1.7519\\tanh(\\frac{2}{3}x)\\end{align*}$",
            func_range: "(-1.7519 , 1.7519)",
            func_contin: "C" + "∞",
            func_mono: "✅",
            func_origin: "❌",
            func_symm: "Anti-Symmetrical",
            func_ref: "http://yann.lecun.com/exdb/publis/pdf/lecun-98b.pdf",
            func_primer:
              "<b>LeCun Tanh</b> (也叫<b>Scaled Tanh</b>)，Tanh的缩放版本. 有一些提升学习能力的特性: f(± 1) = ±1; 在x=1处二阶导最大;有效增益接近1. 可以查看参考文献."
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f'(x)&=1.7519*\\frac{2}{3}(1-\\tanh^2(\\frac{2}{3}x))\\\\&=1.7519*\\frac{2}{3}-\\frac{2}{3*1.7519}f(x)^2\\end{align*}$",
            deriv_func_range: "(0, 1.167933]",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "✅",
            deriv_func_van: "Yes",
            deriv_func_exp: "Yes",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -2, 2];
        asymptote_top = 1.7519;
        asymptote_bottom = -1.7519;
        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: 1.7519 * Math.tanh((2 * i) / 3.0)
          });
          lineData_deriv.push({
            x: I,
            y:
              (2.0 / 3.0) * 1.7519 * (1 - Math.pow(Math.tanh((2 * i) / 3.0), 2))
          });
        }
        break;

      case "leakyrelu":
        func_tags = [
          {
            func_tex:
              "$f(x) =\\begin{cases}x & \\text{for } x\\geq0\\\\0.01x & \\text{for } x<0\\end{cases} $",
            func_range: "(-∞, ∞)",
            func_contin: "C" + "⁰",
            func_mono: "✅",
            func_origin: "✅",
            func_symm: "不对称",
            func_ref:
              "https://pdfs.semanticscholar.org/367f/2c63a6f6a10b3b64b8729d601e69337ee3cc.pdf",
            func_primer:
              "经典ReLU的变形，Leaky ReLU对于负值输入，有非常小的斜率。因为导数总是非零，允许基于梯度的学习（无论多么慢），减轻了死亡神经元现象。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'(x) =\\begin{cases}1 & \\text{for } x\\geq0\\\\0.01 & \\text{for } x<0\\end{cases} $",
            deriv_func_range: "{0.01, 1}",
            deriv_func_contin: "❌",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "No",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -3, 3];
        for (var i = -3; i < 3; i = i + 0.001) {
          if (i < 0) {
            lineData.push({
              x: I,
              y: 0.01 * I
            });
            lineData_deriv.push({
              x: I,
              y: 0.01
            });
          } else {
            lineData.push({
              x: I,
              y: I
            });
            lineData_deriv.push({
              x: I,
              y: 1
            });
          }
        }
        break;
      case "gaussian":
        func_tags = [
          {
            func_tex: "$\\begin{align*}f(x)=e^{-x^2}\\end{align*}$",
            func_range: "(0, 1]",
            func_contin: "C" + "∞",
            func_mono: "❌",
            func_origin: "❌",
            func_symm: "Symmetrical",
            func_ref: "",
            func_primer:
              "不要与径向基函数网络（RBFN）中常用的高斯核混淆，高斯函数不太受多层感知器类型模型的欢迎。尽管一阶导数快速收敛为零，但它完全可微分且对称。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f'(x)&=-2xe^{-x^2}\\\\ &= -2x f(x)\\end{align*}$",
            deriv_func_range: "(-∞, &infin)",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -1.5, 1.5];

        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: Math.exp(-Math.pow(i, 2))
          });
          lineData_deriv.push({
            x: I,
            y: -2 * i * Math.exp(-Math.pow(i, 2))
          });
        }
        break;
      case "absolute":
        func_tags = [
          {
            func_tex: "$\\begin{align*}f(x)=|x|\\end{align*}$",
            func_range: "[0, ∞)",
            func_contin: "C" + "⁰",
            func_mono: "❌",
            func_origin: "❌",
            func_symm: "Symmetrical",
            func_ref: "",
            func_primer:
              "顾名思义，Absolute激活函数返回输入的绝对值。它的导数很容易计算，除了0以外的任何地方定义。由于导数的大小等于1，这种激活函数不会受到消失/爆炸梯度的影响。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'(x) =\\begin{cases}-1 & \\text{for } x<0\\\\1 & \\text{for } x>0\\\\? & \\text{for } x=0\\end{cases}$",
            deriv_func_range: "{-1, 1}",
            deriv_func_contin: "❌",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "No",
            deriv_func_exp: "No",
            deriv_func_sat: "No",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -2, 2];

        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: Math.abs(i)
          });
          lineData_deriv.push({
            x: I,
            y: 2 * (i >= 0) - 1
          });
        }
        break;

      case "probit":
        func_tags = [
          {
            func_tex:
              "$\\begin{align*}f(x)&=\\Phi(x)\\\\&=\\sqrt{2}\\,\\operatorname{erf}^{-1}(2x-1)\\end{align*}$",
            func_range: "(-∞, ∞)",
            func_contin: "C∞",
            func_mono: "✅",
            func_origin: "✅",
            func_symm: "❌",
            func_ref: "",
            func_primer: ""
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f(x)&=\\sqrt{2\\pi}\\exp^{[\\operatorname{erf}^{-1}(2x-1)]^2}\\\\&=\\sqrt{2}\\,\\operatorname{erf}^{-1}(2x-1)\\end{align*}$",
            deriv_func_range: "(0, 1]",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "✅",
            deriv_func_van: "No",
            deriv_func_exp: "❌",
            deriv_func_sat: "❌",
            deriv_func_dead: "❌"
          }
        ];

        axis_limits = [-1, 1, -3, 3];
        alert(Math.exp(-Math.pow(1, 2) / 2) / Math.sqrt(2 * Math.PI));
        for (var i = 0.0005; i <= 1.0005; i = i + 0.0005 / 3) {
          temp_val = Math.sqrt(2) * erfINV(2 * i - 1);
          lineData.push({
            x: I,
            y: temp_val
          });
          lineData_deriv.push({
            x: I,
            y: Math.exp(-Math.pow(temp_val, 2) / 2) / Math.sqrt(2 * Math.PI)
          });
        }
        break;
      case "hardsigmoid":
        func_tags = [
          {
            func_tex:
              "$f(x) =\\begin{cases}0 & \\text{for } x<-2.5\\\\0.2x + 0.5 & \\text{for } -2.5\\geq x\\leq 2.5 \\\\1 & \\text{for } x>2.5\\end{cases} $",
            func_range: "[0,1]",
            func_contin: "C" + "⁰",
            func_mono: "✅",
            func_origin: "❌",
            func_symm: "不对称",
            func_ref: "https://arxiv.org/pdf/1603.00391.pdf",
            func_primer:
              "<b>Hard Sigmoid</b>是Logistic Sigmoid激活函数的分段线性近似。它更容易计算，这使得学习速度更快。也存在零值一阶导数， 导致死神经元/慢学习（参见ReLU）。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f(x) =\\begin{cases}0 & \\text{for } x<-2.5\\\\0.2 & \\text{for } -2.5\\geq x\\leq 2.5 \\\\0 & \\text{for } x>2.5\\end{cases} $",
            deriv_func_range: "{0, 0.2}",
            deriv_func_contin: "❌",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "No",
            deriv_func_dead: "Yes"
          }
        ];

        axis_limits = [-3, 3, -1.5, 1.5];
        for (var i = -3; i <= 3; i = i + 0.001) {
          if ((i >= -2.5) & (i <= 2.5)) {
            lineData.push({
              x: I,
              y: 0.2 * i + 0.5
            });
            lineData_deriv.push({
              x: I,
              y: 0.2
            });
          } else {
            lineData.push({
              x: I,
              y: i > 2.5
            });
            lineData_deriv.push({
              x: I,
              y: 0
            });
          }
        }
        break;
      case "hardtanh":
        func_tags = [
          {
            func_tex:
              "$f(x) =\\begin{cases}-1 & \\text{for } x<-1\\\\x & \\text{for } -1\\geq x\\leq 1 \\\\1 & \\text{for } x>1\\end{cases} $",
            func_range: "[-1,1]",
            func_contin: "C" + "⁰",
            func_mono: "✅",
            func_origin: "✅",
            func_symm: "Anti-Symmetrical",
            func_ref: "https://arxiv.org/pdf/1603.00391.pdf",
            func_primer:
              "<b>HardTanh</b> 是Tanh激活函数的分段线性近似。它更容易计算，这使得学习速度更快。也存在零值一阶导数， 导致死神经元/慢学习（参见ReLU）。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f(x) =\\begin{cases}0 & \\text{for } x<-1\\\\1 & \\text{for } -1\\geq x\\leq 1 \\\\0 & \\text{for } x>1\\end{cases} $",
            deriv_func_range: "{0,1}",
            deriv_func_contin: "❌",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "No",
            deriv_func_exp: "No",
            deriv_func_sat: "No",
            deriv_func_dead: "Yes"
          }
        ];

        axis_limits = [-3, 3, -1.5, 1.5];
        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: Math.max(-1, Math.min(1, i))
          });
          lineData_deriv.push({
            x: I,
            y: i >= -1 && i <= 1
          });
        }
        break;

      case "symmsigmoid":
        func_tags = [
          {
            func_tex:
              "$\\begin{align*}f(x)&=\\tanh(x/2)\\\\&=\\frac{1-e^{-x}}{1+e^{-x}}\\end{align*}$",
            func_range: "(-1, -1)",
            func_contin: "C" + "∞",
            func_mono: "✅",
            func_origin: "❌",
            func_symm: "Symmetrical",
            func_ref: "",
            func_primer:
              "对称Sigmoid是Tanh激活的另一种替代方法（它实际上相当于Tanh激活，输入减半）。像Tanh一样，它是反对称的，零中心，可微分并且值域在[-1, 1]。它更扁平的形状和更缓慢下降的导数表明它可以更有效地学习。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f(x)&=0.5(1-\\tanh^2(x/2))\\\\&=0.5(1-f(x)^2)\\end{align*}$",
            deriv_func_range: "(0, 0.5]",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "✅",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -1.5, 1.5];
        asymptote_top = 1;
        asymptote_bottom = -1;
        for (var i = -3; i <= 3; i = i + 0.001) {
          lineData.push({
            x: I,
            y: Math.tanh(i / 2)
          });
          lineData_deriv.push({
            x: I,
            y: (1 - Math.pow(Math.tanh(i / 2), 2)) / 2
          });
        }
        break;
      case "loglog":
        func_tags = [
          {
            func_tex: "$\\begin{align*}f(x)=1-e^{-e^{x}}\\end{align*}$",
            func_range: "(0, 1)",
            func_contin: "C" + "∞",
            func_mono: "✅",
            func_origin: "❌",
            func_symm: "不对称",
            func_ref: "",
            func_primer:
              "函数值域(0, 1), <b>Complementary Log Log</b> (or just <b>Log Log</b>) 是sigmoid的很好的替代品. 更快饱和且在原点函数值超过0.5"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$\\begin{align*}f'(x)=e^{x}(e^{-e^{x}}) = e^{x-e^{x}}\\end{align*}$",
            deriv_func_range: "(0, 1/e]",
            deriv_func_contin: "✅",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes",
            deriv_func_exp: "No",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        axis_limits = [-3, 3, -1.5, 1.5];
        asymptote_top = 1;
        for (var i = -3; i <= 3; i = i + 0.001) {
          temp_val = Math.exp(-Math.exp(i));
          lineData.push({
            x: I,
            y: 1 - temp_val
          });
          lineData_deriv.push({
            x: I,
            y: Math.exp(i) * temp_val
          });
        }
        break;
      case "prelu":
        document.getElementById("alpha_input_label").innerHTML = "α";
        document.getElementById("alpha_input_label").style.display = "block";
        document.getElementById("alpha_input").style.display = "block";
        var alpha = parseFloat(document.getElementById("alpha_input").value);
        func_tags = [
          {
            func_tex:
              "$f_{\\alpha}(x) =\\begin{cases}x & \\text{for } x\\geq0\\\\\\alpha x & \\text{for } x<0\\end{cases} $",
            func_range: "(-∞, ∞) α <0, [0, ∞) α ≥0",
            func_contin: "C" + "⁰" + " (iff α ≠ 1)",
            func_mono: "✅ (iff α ≥0)",
            func_origin: "❌ iff α≠1",
            func_symm: "asymetrical (iff |α|≠1)",
            func_ref: "https://arxiv.org/abs/1502.01852",
            func_primer:
              "<b>Parameteric Rectified Linear Unit</b> (<b>PReLU</b>)参数整流线性单元（PReLU），它与RReLU和Leaky ReLU有一些相似之处，因为它包含负值输入的线性项。关键的区别在于，该线的斜率实际上是作为参数在模型训练期间学习的。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'_{\\alpha}(x) =\\begin{cases}1 & \\text{for } x\\geq0\\\\\\alpha & \\text{for } x<0\\end{cases} $",
            deriv_func_range: "{α, 1}",
            deriv_func_contin: "❌ (iff α ≠ 1)",
            deriv_func_mono: "❌ (iff α ≠ 1)",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes (iff α<1)",
            deriv_func_exp: "No (iff α<1)",
            deriv_func_sat: "No",
            deriv_func_dead: "No (iff α≠0)"
          }
        ];

        axis_limits = [-3, 3, -3, 3];
        for (var i = -3; i < 3; i = i + 0.001) {
          if (i < 0) {
            lineData.push({
              x: I,
              y: alpha * I
            });
            lineData_deriv.push({
              x: I,
              y: alpha
            });
          } else {
            lineData.push({
              x: I,
              y: I
            });
            0;
            lineData_deriv.push({
              x: I,
              y: 1
            });
          }
        }
        break;

      case "rrelu":
        document.getElementById("rrelu_button").style.display = "block";
        var alpha = 6 * Math.random() - 3;
        func_tags = [
          {
            func_tex:
              "$f(x) =\\begin{cases}x & \\text{for } x\\geq0\\\\\\alpha x & \\text{for } x<0\\end{cases} $",
            func_range: "(-∞, ∞) α <0, [0, ∞) α ≥0",
            func_contin: "C" + "⁰" + " (iff α ≠ 1)",
            func_mono: "✅ (iff α ≥0)",
            func_origin: "❌ iff α≠1",
            func_symm: "Asymetrical (iff |α|≠1)",
            func_ref: "https://arxiv.org/abs/1505.00853",
            func_primer:
              "<b>Randomized Leaky Rectified Linear Unit</b> (<b>RReLU</b>), 关键的区别在于该线的斜率是为每个节点随机分配的（通常来自均匀分布）"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'(x) =\\begin{cases}1 & \\text{for } x\\geq0\\\\\\alpha & \\text{for } x<0\\end{cases} $",
            deriv_func_range: "{α, 1}",
            deriv_func_contin: "❌ (iff α ≠ 1)",
            deriv_func_mono: "❌ (iff α ≠ 1)",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes (iff α<1)",
            deriv_func_exp: "No (iff α<1)",
            deriv_func_sat: "No",
            deriv_func_dead: "No (iff α≠0)"
          }
        ];

        axis_limits = [-3, 3, -3, 3];
        for (var i = -3; i < 3; i = i + 0.001) {
          if (i < 0) {
            lineData.push({
              x: I,
              y: alpha * I
            });
            lineData_deriv.push({
              x: I,
              y: alpha
            });
          } else {
            lineData.push({
              x: I,
              y: I
            });
            lineData_deriv.push({
              x: I,
              y: 1
            });
          }
        }
        break;
      case "elu":
        document.getElementById("alpha_input_label").innerHTML = "α";
        document.getElementById("alpha_input_label").style.display = "block";
        document.getElementById("alpha_input").style.display = "block";
        var alpha = parseFloat(document.getElementById("alpha_input").value);
        asymptote_bottom = -alpha;
        func_tags = [
          {
            func_tex:
              "$f(x) = \\begin{cases}\\alpha(e^x - 1) & \\text{for } x < 0\\\\x & \\text{for } x \\ge 0\\end{cases} $",
            func_range: "(-α, ∞) α <0, [0, ∞) α ≥0",
            func_contin: "C" + "⁰" + " (iff α ≠ 1)",
            func_mono: "✅ (iff α ≥0)",
            func_origin: "❌ iff α≠1",
            func_symm: "不对称",
            func_ref: "https://arxiv.org/abs/1511.07289",
            func_primer:
              "<b>Exponential Linear Unit</b> (<b>ELU</b>) 包含负指数项，防止神经元死亡。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'(x) = \\begin{cases} \\alpha e^{x} = f(x) + \\alpha & \\text{for } x < 0\\\\1 & \\text{for } x \\ge 0\\end{cases}$",
            deriv_func_range: "{(0, α] ∪ 1}",
            deriv_func_contin: "❌ (unless α = 1)",
            deriv_func_mono: "✅ (unless |α|>1)",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes",
            deriv_func_exp: "No (iff α<1)",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No (iff α≠0)"
          }
        ];

        axis_limits = [-3, 3, -3, 3];
        for (var i = -3; i < 3; i = i + 0.001) {
          if (i < 0) {
            temp_val = alpha * (Math.exp(i) - 1);
            lineData.push({
              x: I,
              y: temp_val
            });
            lineData_deriv.push({
              x: I,
              y: temp_val + alpha
            });
          } else {
            lineData.push({
              x: I,
              y: I
            });
            0;
            lineData_deriv.push({
              x: I,
              y: 1
            });
          }
        }
        break;
      case "selu":
        func_tags = [
          {
            func_tex:
              "$f(x) = \\lambda \\begin{cases}\\alpha(e^x - 1) & \\text{for } x < 0\\\\x & \\text{for } x \\ge 0 \\end{cases}\\\\\\text{ with } \\lambda = 1.0507, \\alpha = 1.67326 $",
            func_range: "(-λα, ∞)",
            func_contin: "C" + "⁰",
            func_mono: "✅",
            func_origin: "❌",
            func_symm: "不对称",
            func_ref: "https://arxiv.org/abs/1706.02515",
            func_primer:
              "<b>Scaled Exponential Linear Unit</b> (<b>SELU</b>) ，ELU的变形, 但固定 λ = 1.0507,  α=1.67326. 这些值使得输出信号均值为0，方差为1，是自归一化神经网络的基础(Self-Normalising Neural Networks, SNNs)."
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'(x) = \\begin{cases}\\lambda\\alpha e^{x} = \\lambda(f(x) + \\alpha) & \\text{for } x < 0\\\\\\lambda & \\text{for } x \\ge 0\\end{cases}$",
            deriv_func_range: "(0, λα)",
            deriv_func_contin: "❌",
            deriv_func_mono: "❌",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes",
            deriv_func_exp: "Yes",
            deriv_func_sat: "Yes",
            deriv_func_dead: "No"
          }
        ];

        asymptote_bottom = -1.0507 * 1.67326;

        axis_limits = [-3, 3, -3, 3];
        for (var i = -3; i < 3; i = i + 0.001) {
          if (i < 0) {
            temp_val = 1.0507 * 1.67326 * (Math.exp(i) - 1);
            lineData.push({
              x: I,
              y: temp_val
            });
            lineData_deriv.push({
              x: I,
              y: 1.0507 * (temp_val + 1.67326)
            });
          } else {
            lineData.push({
              x: I,
              y: 1.0507 * I
            });
            lineData_deriv.push({
              x: I,
              y: 1.0507
            });
          }
        }
        break;
      case "srelu":
        document.getElementById("alpha_input").style.display = "block";
        document.getElementById("alpha_input_label").style.display = "block";
        document.getElementById("alpha_input_r").style.display = "block";
        document.getElementById("alpha_input_r_label").style.display = "block";
        document.getElementById("t_input_l").style.display = "block";
        document.getElementById("t_input_l_label").style.display = "block";
        document.getElementById("t_input_r").style.display = "block";
        document.getElementById("t_input_r_label").style.display = "block";
        var alpha_l = parseFloat(document.getElementById("alpha_input").value);
        var alpha_r = parseFloat(
          document.getElementById("alpha_input_r").value
        );
        var t_l = parseFloat(document.getElementById("t_input_l").value);
        var t_r = parseFloat(document.getElementById("t_input_r").value);

        document.getElementById("alpha_input_label").innerHTML =
          "α<sub>l</sub>";

        func_tags = [
          {
            func_tex:
              "$f_{t_l,a_l,t_r,a_r}(x) = \\begin{cases}t_l + a_l (x - t_l) & \\text{for } x \\le t_l\\\\x & \\text{for } t_l < x < t_r\\\\t_r + a_r (x - t_r) & \\text{for } x \\ge t_r\\end{cases}$",
            func_range: "(-∞, ∞)",
            func_contin: "C" + "⁰" + " (unless α_l=a_r=1)",
            func_mono: "✅ (unless ∃ α<0)",
            func_origin: "✅ (unless t_l>0 or t_r<0)",
            func_symm: "Asymmetrical (generally)",
            func_ref: "https://arxiv.org/abs/1512.07030",
            func_primer:
              "<b>S-shaped Rectified Linear Activation Unit</b> (<b>SReLU</b>) ，由3段线性函数组成. 这些函数及其导数有相同的交点，在学习过程中学习这些参数。"
          }
        ];

        deriv_func_tags = [
          {
            deriv_func_tex:
              "$f'_{t_l,a_l,t_r,a_r}(x) = \\begin{cases}a_l & \\text{for } x \\le t_l\\\\1   & \\text{for } t_l < x < t_r\\\\a_r & \\text{for } x \\ge t_r\\end{cases}$",
            deriv_func_range: "{α_l, α_r, 1}",
            deriv_func_contin: "❌ (unless α_l=α_r=1)",
            deriv_func_mono: "❌ (unless α_l≤1 & α_r≥1)",
            deriv_func_symm: "❌",
            deriv_func_van: "Yes (iff ∃ α<1)",
            deriv_func_exp: "Yes (iff ∃ α>1)",
            deriv_func_sat: "No",
            deriv_func_dead: "No (iff ∄ α=0)"
          }
        ];

        axis_limits = [-3, 3, -3, 3];
        for (var i = -3; i < 3; i = i + 0.001) {
          if (i <= t_l) {
            lineData.push({
              x: I,
              y: t_l + alpha_l * (i - t_l)
            });
            lineData_deriv.push({
              x: I,
              y: alpha_l
            });
          } else if (i >= t_r) {
            lineData.push({
              x: I,
              y: t_r + alpha_r * (i - t_r)
            });
            lineData_deriv.push({
              x: I,
              y: alpha_r
            });
          } else {
            lineData.push({
              x: I,
              y: I
            });
            lineData_deriv.push({
              x: I,
              y: 1
            });
          }
        }
        break;
    }

    xRange.domain(axis_limits.slice(0, 2));
    yRange.domain(axis_limits.slice(2, 4));

    var vis = d3.select("#visualisation");

    var lineFunc = d3.svg
      .line()
      .x(function(d) {
        return xRange(d.x);
      })
      .y(function(d) {
        return yRange(d.y);
      })
      .interpolate("linear");

    var axis_ratio =
      axis_limits[1] -
      axis_limits[0] -
      (axis_limits[3] - axis_limits[2]) / (axis_limits[1] - axis_limits[0]);

    vis
      .select("#func") // change the line
      .transition()
      .duration(1000)
      .attr("d", lineFunc(lineData));

    vis
      .select("#deriv_func") // change the line
      .transition()
      .duration(1000)
      .attr("d", lineFunc(lineData_deriv));

    vis
      .select(".y.axis") // change the y axis
      .transition()
      .duration(1000)
      .call(yAxis);

    vis
      .select(".x.axis") // change the x axis
      .transition()
      .duration(1000)
      .call(xAxis);

    MathJax.Hub.Config({
      tex2jax: {
        inlineMath: [["$", "$"], ["\\(", "\\)"]],
        processEscapes: true
      }
    });

    MathJax.Hub.Queue(["Typeset", MathJax.Hub]);

    vis
      .select("#func_equation")
      .select("div")
      .transition()
      .text(func_tags[0].func_tex);

    vis
      .select("#deriv_func_equation")
      .select("div")
      .text(deriv_func_tags[0].deriv_func_tex);

    MathJax.Hub.Queue(["Typeset", MathJax.Hub]);

    vis
      .select("#func_contin")
      .transition()
      .text("连续性: " + func_tags[0].func_contin);

    vis
      .select("#func_symm")
      .transition()
      .text("对称性: " + func_tags[0].func_symm);

    vis
      .select("#func_range")
      .transition()
      .text("值域: " + func_tags[0].func_range);

    vis
      .select("#func_mono")
      .transition()
      .text("单调性: " + func_tags[0].func_mono);

    vis
      .select("#func_origin")
      .transition()
      .text("Identity at Origin: " + func_tags[0].func_origin);

    if (func_tags[0].func_ref == "") {
      vis.select("#func_ref").html("");
    } else {
      vis
        .select("#func_ref")
        .html(
          '<a href="' +
            func_tags[0].func_ref +
            '" target="_blank" style="fill:blue">Reference</a>'
        );
    }

    // update derivative info table

    vis
      .select("#deriv_func_contin")
      .transition()
      .text("连续性: " + deriv_func_tags[0].deriv_func_contin);

    vis
      .select("#deriv_func_range")
      .transition()
      .text("值域: " + deriv_func_tags[0].deriv_func_range);

    vis
      .select("#deriv_func_mono")
      .transition()
      .text("单调性: " + deriv_func_tags[0].deriv_func_mono);

    vis
      .select("#deriv_func_origin")
      .transition()
      .text("Identity at Origin: " + deriv_func_tags[0].deriv_func_origin);

    vis
      .select("#deriv_func_symm")
      .transition()
      .text("Identity at Origin: " + deriv_func_tags[0].deriv_func_symm);

    // update asymptote lines

    vis
      .select("#top_asymptote")
      .transition()
      .duration(1000)
      .attr(
        "d",
        lineFunc([
          { x: axis_limits[0], y: asymptote_top },
          { x: axis_limits[1], y: asymptote_top }
        ])
      );

    vis
      .select("#bottom_asymptote")
      .transition()
      .duration(1000)
      .attr(
        "d",
        lineFunc([
          { x: axis_limits[0], y: asymptote_bottom },
          { x: axis_limits[1], y: asymptote_bottom }
        ])
      );

    vis
      .selectAll(".tick")
      .filter(function(d) {
        return d === 0;
      })
      .remove();

    document.getElementById("func_primer").innerHTML = func_tags[0].func_primer;

    if (
      activ_func == "srelu" ||
      activ_func == "prelu" ||
      activ_func == "rrelu" ||
      activ_func == "elu"
    ) {
      vis
        .select("#deriv_func_exp")
        .select("tspan")
        .text("Exploding: ")
        .append("svg:tspan")
        .style(
          "fill",
          deriv_func_tags[0].deriv_func_exp.indexOf("Yes") > -1
            ? "red"
            : "#00e600"
        )
        .text(deriv_func_tags[0].deriv_func_exp);

      vis
        .select("#deriv_func_van")
        .select("tspan")
        .text("Vanishing: ")
        .append("svg:tspan")
        .style(
          "fill",
          deriv_func_tags[0].deriv_func_van.indexOf("Yes") > -1
            ? "red"
            : "#00e600"
        )
        .text(deriv_func_tags[0].deriv_func_van);
    } else {
      vis
        .select("#deriv_func_exp")
        .select("tspan")
        .text("梯度爆炸: ")
        .append("svg:tspan")
        .style(
          "fill",
          deriv_func_tags[0].deriv_func_exp.indexOf("Yes") > -1
            ? "red"
            : "#00e600"
        )
        .text(deriv_func_tags[0].deriv_func_exp);

      vis
        .select("#deriv_func_van")
        .select("tspan")
        .text("梯度消失: ")
        .append("svg:tspan")
        .style(
          "fill",
          deriv_func_tags[0].deriv_func_van.indexOf("Yes") > -1
            ? "red"
            : "#00e600"
        )
        .text(deriv_func_tags[0].deriv_func_van);
    }
    vis
      .select("#deriv_func_sat")
      .select("tspan")
      .select("tspan")
      .style(
        "fill",
        deriv_func_tags[0].deriv_func_sat.indexOf("Yes") > -1
          ? "red"
          : "#00e600"
      )
      .text(deriv_func_tags[0].deriv_func_sat);

    vis
      .select("#deriv_func_dead")
      .select("tspan")
      .select("tspan")
      .style(
        "fill",
        deriv_func_tags[0].deriv_func_dead.indexOf("Yes") > -1
          ? "red"
          : "#00e600"
      )
      .text(deriv_func_tags[0].deriv_func_dead);
  }
</script>
